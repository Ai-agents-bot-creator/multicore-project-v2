# Document templates

Section skeletons for the ten files. Copy the shape, fill it from the project's own sources, and
delete any line that does not apply. Keep the headings — the checker and the cross-links depend on
them.

---

## 00_ARCHITECTURE.md

```markdown
# 00 — Architecture

## 1. System overview          <- what the design is, in one paragraph + a block diagram
## 2. Cache hierarchy           <- L1/L2 geometry, inclusion policy, per-line word layout
## 3. Coherence protocol        <- MESI states, transition rules, message set with directions
## 4. Interconnect              <- topology, routing, VCs, flow control, arbitration + fairness
## 5. Address map and tags      <- field decomposition table for each configuration
## 6. Scope                     <- explicitly IN and OUT (cores, gated features)
## 7. Module map                <- module -> parent -> build order -> owning spec section
```

Every width, depth and encoding in §2–§5 is copied from the spec with the source section cited.
§6 must name what the project does **not** include (processor cores, gated DMA) — a budget that
excludes cores read as a full-system claim otherwise.

---

## 01_DECISION_LOG.md

One row per contested point.

```markdown
# 01 — Decision log

| # | Contested point | Option A | Option B | ... | **Ruling** | Deciding basis | Status |
|---|---|---|---|---|---|---|---|
| A | Directory state field width | 3 b | 4 b | | **3 bits, exactly saturated** | ... | settled |
```

Rules:
- One row per decision, not per module. A decision that was never contested does not get a row.
- The ruling cell is the single source of truth. `00` and `06` cite it, never restate it.
- Keep the ledger's own labelling series (letters, `AA`, `AB`, …) consistent; do not introduce a
  second naming scheme, and do not reuse a label.
- Status: `settled` / `provisional` / `open`. A provisional ruling must also appear as an open item
  in the scratchpad.

---

## 02_PROBLEM_LOG.md

One entry per defect, always in this shape — the chain is the point, not the prose.

```markdown
# 02 — Problem log

## P-001 — <one-line symptom>
- **Symptom:** what was observed (failing check, wrong number, wrong behaviour)
- **Reproduction:** the exact command or scenario that shows it
- **Root cause:** why it happened
- **Resolution:** what changed, in which file
- **Verification:** the check that now passes, and its result
- **Lesson:** what to do differently next time
```

Never close an entry without a verification line. A problem log with unverified resolutions is a
list of hopes.

---

## 03_CHANGELOG.md

```markdown
# 03 — Changelog

## Milestone N — <date>
- **Added:** modules written, with their build order
- **Decided:** rulings landed (reference the decision-log row)
- **Closed:** open items resolved
- **Open:** what is still outstanding
```

One section per milestone, newest first. If a change touches a number that also appears in
`00` or `06`, say so in that milestone entry so the reader knows to look.

---

## 04_TECH_STACK.md

```markdown
# 04 — Tech stack

| Layer | Tool | Version | Purpose |
|---|---|---|---|
| Design language | SystemVerilog | | |
| Simulation | | | |
| Lint / CDC | | | |
| Formal | | | |
| Coverage | | | |
| Synthesis / P&R | | | |
| FPGA programming | | | |
| Reference model | | | |
```

Add a one-line note per tool: what it is used for and what it is *not* used for.

---

## 05_DATA_SAFETY.md

```markdown
# 05 — Data safety

## 1. IP boundaries        <- third-party code, licence, where it may and may not be used
## 2. Secrets and credentials   <- what must never enter the repo, and how it is supplied
## 3. Personal and licence data  <- board files, vendor material, student data
## 4. Repository hygiene   <- what is ignored, what is generated, what is archived
```

Do not put a real credential, key or licence text in this file — name the category and the
handling rule.

---

## 06_VERIFICATION_PLAN.md

```markdown
# 06 — Verification plan

## 1. Strategy           <- directed / constrained-random / formal, and what each covers
## 2. Assertion set      <- categories, count, scope; state the count's source
## 3. Formal method      <- BMC depth, k-induction depth, liveness bound; mark proposed vs fixed
## 4. Reference model    <- what it shadows, how it is compared, what a mismatch means
## 5. Coverage criteria  <- numeric targets per coverage type
## 6. Directed tests     <- the test list and what each exercises
## 7. Exit criteria      <- what must hold before a module is called green
```

Counts are read from the spec at write time. If the spec marks a depth *proposed*, carry it as
proposed. Exit criteria are conjunctive: a module is green only when every listed condition holds.

---

## 07_PHYSICAL_DESIGN.md

```markdown
# 07 — Physical design

## 1. Device and board
## 2. Clock and reset strategy
## 3. IO budget and pin map
## 4. Resource budget      <- table: resource | available | target | ceiling | risk
## 5. Timing target        <- frequency, and the constraint that must be authored
## 6. Implementation flow
## 7. Fallbacks            <- ordered, if fit or timing fails
```

The budget table separates **target** from **ceiling** — they are different numbers, and collapsing
them makes the design look like it consumes the whole device. Per-module breakdowns belong here so
a later area regression can be attributed.

---

## 08_PORTFOLIO_BIO.md

```markdown
# 08 — Portfolio bio

## 1. One-paragraph narrative
## 2. What I built              <- concrete, verifiable, no claim the repo does not support
## 3. Hard problems solved      <- each with the trade-off, not just the result
## 4. Interview talking points  <- what to say, what to be ready to defend
```

Every claim in §2 and §3 must be traceable to a file in `docs/` or to the spec. If the repo cannot
show it, it does not go in the bio.

---

## AI_SCRATCHPAD.md

```markdown
# AI scratchpad

## Where we are
## In flight
## Next action           <- one concrete, actionable step
## Open items            <- each names the file that owns it
## Recent findings       <- what the last session discovered and fixed
```

Keep it to what a fresh session needs to resume: no history, no narrative. The decision log and
changelog carry history; this carries *state*.
