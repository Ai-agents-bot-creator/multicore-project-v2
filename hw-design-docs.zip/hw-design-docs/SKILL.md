---
name: hw-design-docs
description: |
  Create and maintain a numbered documentation suite (docs/00_ARCHITECTURE.md … docs/08_PORTFOLIO_BIO.md
  plus docs/AI_SCRATCHPAD.md) for a hardware design project — RTL, FPGA, SoC, or cache-coherent
  accelerator work. Use when the user asks to "set up the docs", "create the documentation suite",
  "document this hardware project", "write the architecture doc / decision log / problem log /
  changelog / tech stack / data safety / verification plan / physical design / portfolio bio",
  "add an AI scratchpad", or asks to bring an existing docs/ folder up to date after a milestone.
  Covers extracting every number from the project's own spec rather than restating it from memory.
  Do NOT use for: a single README or project index; reviewing a specification document for defects
  (that is a spec-review workflow); slide decks (use the pptx skill); Word deliverables (use the docx
  skill); or writing RTL/testbench code itself.
---

# Hardware Design Documentation Suite

Ten files, one directory, kept in lockstep with the spec and the RTL tree. The suite exists so a
mentor, a reviewer, or a future session can reconstruct every decision without reading the whole
conversation.

## Inputs to collect

Take these from the repo before writing anything; each one changes the content:

| Input | Where it usually is | Used by |
|---|---|---|
| Spec sources (white paper, spec sheet, LLD diagrams) | `white_papers/`, `specs/`, `docs/` | 00, 06, 07 — every number comes from here |
| Module tree / build order | `BUILD_ORDER.csv`, `rtl/` | 00, 03, 06 |
| Assertion set and verification method | spec §verification, `tb/sva/` | 06 |
| Device and toolchain | `syn/`, project scripts, board files | 04, 07 |
| Prior decisions and known problems | existing `docs/`, git history, `AI_SCRATCHPAD.md` | 01, 02, 03 |

If a number is not in the spec, write **"not specified"** and record it as an open item — do not
invent a value. An invented number that later contradicts the spec is the single most expensive
failure this suite can produce, because the spec review and the docs review then disagree.

## Procedure

1. **Survey the repo before writing.** Locate the spec sources, the RTL/testbench/synthesis trees,
   the module list and any existing docs. Fix the file inventory from what exists, not from what a
   template implies. Note which modules are out of scope (processor cores, DMA behind a gate) —
   the docs must say so, because an area budget that excludes cores reads as a full-system claim.

2. **Create `docs/` and write the ten files** using the skeletons in
   `references/doc-templates.md`. Keep each file to its purpose:
   - `00_ARCHITECTURE.md` — system, hierarchy, protocol states, interconnect microarchitecture.
     Every structural number traces to the spec.
   - `01_DECISION_LOG.md` — one ADR row per contested point: what was contested, each candidate,
     the ruling, the basis, the status. Rulings live here and nowhere else.
   - `02_PROBLEM_LOG.md` — one entry per defect in the fixed shape
     **Symptom → Reproduction → Root Cause → Resolution → Verification → Lesson**.
   - `03_CHANGELOG.md` — milestone-to-milestone deltas: which modules appeared, which rulings
     landed, which open items closed.
   - `04_TECH_STACK.md` — language, simulators, lint/CDC, formal, synthesis, FPGA tools, targets.
   - `05_DATA_SAFETY.md` — IP boundaries, secret handling, third-party licence obligations,
     what must never enter the repo.
   - `06_VERIFICATION_PLAN.md` — the assertion plan, method and depth, the reference model,
     coverage criteria, and the exit criteria. Counts come from the spec.
   - `07_PHYSICAL_DESIGN.md` — device, clock/reset, IO budget, resource budget table, timing
     target, and the implementation flow.
   - `08_PORTFOLIO_BIO.md` — the narrative and the interview talking points; a claim in here must
     be defensible in the files above.
   - `AI_SCRATCHPAD.md` — the running context: where the project is, what is in flight, what the
     next action is. Keep it short enough to be re-read every session.

3. **Derive, do not restate.** For each file, pull the numbers from the spec at the moment of
   writing and cite the source (section or file) inline. If the spec and a doc disagree, the spec
   wins and the doc is corrected — the reverse never happens silently.

4. **Cross-link the suite.** Every ADR should name the doc it constrains; every open item in the
   scratchpad should name the file that owns it. A reader who opens one file should be able to
   reach the rest in one hop.

5. **Run `scripts/check_docs.py`** (see below) and fix what it reports before declaring the suite
   done.

6. **Maintain it.** After any milestone — a ruling, a new module, a closed open item — update the
   affected files in the same change: a ruling lands in `01`, a defect in `02`, a new module in
   `00` and `03`, the verification delta in `06`. A stale suite is worse than no suite, because it
   looks authoritative.

## Output contract

- A `docs/` directory holding the ten files above, each with its section skeleton filled in and
  every number carrying a source.
- `scripts/check_docs.py` reporting **0 failures** on the suite.
- A short summary to the user: the file inventory, which numbers came from the spec, and which
  values are still "not specified" and need a ruling.

## Failure handling

- **Spec missing or contradictory** — do not resolve it silently. Record it as an open item in
  `AI_SCRATCHPAD.md` with the exact conflict quoted, and flag it to the user as needing a ruling.
- **A number is unavailable** — write "not specified", list it as an open item, and move on. Never
  interpolate.
- **The suite already exists** — read it first and *update* rather than regenerate; regenerate only
  when the user asks for a rewrite. Preserve prior decisions and problems; they are the value.
- **The project is not hardware** — say so and do not apply this template. The file names are
  hardware-specific by design.
- **A check in the script fails and the file is correct** — the script is wrong; fix the script
  and say why in the summary. A gate that cries wolf gets ignored.

## Examples

**Input:** "Set up the docs for my cache-coherent multicore RTL project. The spec is in
`white_papers/`, the module list is `BUILD_ORDER.csv`, and we're targeting a ZedBoard."

**Output:** `docs/` with the ten files; `00_ARCHITECTURE.md` quoting tile geometry and the
directory entry width from the spec's address-decomposition table; `01_DECISION_LOG.md` with one
ADR row per contested point already resolved in the spec; `06_VERIFICATION_PLAN.md` with the
assertion count read from the spec's verification section and the BMC/k-induction depths as
*proposed* if the spec marks them proposed; `07_PHYSICAL_DESIGN.md` carrying the device's LUT and
BRAM budget with the per-module breakdown; `AI_SCRATCHPAD.md` listing the open items that still
need a ruling and naming the next module to build. `check_docs.py` reports 0 failures.

**Input:** "Update the docs after we closed the fairness-bound ruling."

**Output:** a new ADR row in `01_DECISION_LOG.md` (contested point, candidates, ruling, basis), a
matching line in `03_CHANGELOG.md`, the affected numbers in `00` and `06` updated in place, and the
open item struck from `AI_SCRATCHPAD.md` — not a regenerated suite.
